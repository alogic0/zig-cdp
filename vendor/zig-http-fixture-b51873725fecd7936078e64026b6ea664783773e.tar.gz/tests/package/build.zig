const std = @import("std");
pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});
    const fixture = b.dependency("http_fixture", .{ .target = target, .optimize = optimize });
    const executable = b.addExecutable(.{ .name = "package-consumer", .root_module = b.createModule(.{ .root_source_file = b.path("main.zig"), .target = target, .optimize = optimize, .imports = &.{.{ .name = "http_fixture", .module = fixture.module("http_fixture") }} }) });
    const run = b.addRunArtifact(executable);
    run.has_side_effects = true;
    b.step("test", "Verify archived package through the public module").dependOn(&run.step);
}
