const std = @import("std");
const F = @import("http_fixture");
const Io = std.Io;
const t = std.testing;
const get = "GET /hello HTTP/1.1\r\nHost: localhost\r\n\r\n";

const Handler = struct {
    entered: Io.Event = .unset,
    release: Io.Event = .unset,
    mode: enum { echo, fail, hold, large, gated, ignored_failure } = .echo,
    fn handle(context: *anyopaque, input: F.Input) anyerror!void {
        const self: *@This() = @ptrCast(@alignCast(context));
        self.entered.set(input.io);
        switch (self.mode) {
            .fail => return error.DeliberateHandlerFailure,
            .hold => try self.release.wait(input.io),
            .gated => if (std.mem.eql(u8, input.request.target, "/slow")) try self.release.wait(input.io),
            .ignored_failure => {
                input.response.send(.{ .body = "too large" }) catch {};
                return;
            },
            .large => {
                const body = try input.allocator.alloc(u8, 16 * 1024 * 1024);
                @memset(body, 'x');
                return input.response.send(.{ .body = body });
            },
            .echo => {},
        }
        try input.response.send(.{ .body = if (input.request.body.len > 0) input.request.body else input.request.target });
    }
};
fn options(handler: *Handler) F.Options {
    return .{
        .address = .{ .ip4 = .{ .bytes = .{ 127, 0, 0, 1 }, .port = 0 } },
        .handler = .{ .context = handler, .handle = Handler.handle },
        .limits = .{ .max_connections = 4, .max_header_bytes = 1024, .max_request_body_bytes = 1024, .max_response_bytes = 1024 },
        .deadlines = .{ .handshake_ms = 1000, .request_head_ms = 1000, .request_total_ms = 2000, .write_ms = 1000 },
        .connection_policy = .close_after_response,
    };
}
fn waitState(server: *F.Server, field: enum { active, finished, failed }, wanted: u64) !void {
    for (0..2000) |_| {
        const state = server.snapshot();
        const value: u64 = switch (field) {
            .active => state.active,
            .finished => state.completed + state.abandoned + state.failures + state.canceled,
            .failed => state.failures,
        };
        if (value >= wanted) return;
        try t.io.sleep(.fromMilliseconds(1), .awake);
    }
    return error.StateWaitTimeout;
}
fn send(stream: Io.net.Stream, wire: []const u8) !void {
    var buffer: [128]u8 = undefined;
    var writer = stream.writer(t.io, &buffer);
    try writer.interface.writeAll(wire);
    try writer.interface.flush();
}
const Probe = struct {
    address: Io.net.IpAddress,
    wire: []const u8,
    output: ?[]u8 = null,
    fn run(self: *@This()) anyerror!void {
        const stream = try self.address.connect(t.io, .{ .mode = .stream });
        defer stream.close(t.io);
        try send(stream, self.wire);
        var buffer: [1024]u8 = undefined;
        var reader = stream.reader(t.io, &buffer);
        self.output = try reader.interface.allocRemaining(t.allocator, .limited(32 * 1024 * 1024));
    }
};
fn request(address: Io.net.IpAddress, wire: []const u8) ![]u8 {
    var probe: Probe = .{ .address = address, .wire = wire };
    errdefer if (probe.output) |out| t.allocator.free(out);
    const Result = union(enum) { operation: anyerror!void, timer: Io.Cancelable!void };
    var results: [2]Result = undefined;
    var select: Io.Select(Result) = .init(t.io, &results);
    defer select.cancelDiscard();
    try select.concurrent(.operation, Probe.run, .{&probe});
    try select.concurrent(.timer, Io.sleep, .{ t.io, .fromSeconds(4), .awake });
    switch (try select.await()) {
        .operation => |result| try result,
        .timer => return error.ProbeTimeout,
    }
    return probe.output.?;
}
fn rejected(server: *F.Server, wire: []const u8, expected: anyerror) !void {
    if (request(server.address(), wire)) |response| {
        defer t.allocator.free(response);
        try t.expectEqualStrings("", response);
    } else |err| if (err != error.ReadFailed) return err;
    try waitState(server, .failed, 1);
    try t.expectEqual(expected, server.snapshot().first_error.?);
}

test "P1-HTTP-01 loopback ownership explicit collision and native mode" {
    try t.expectEqual(@import("builtin").mode, F.compiled_mode);
    var handler: Handler = .{};
    var opts = options(&handler);
    opts.address.ip4.bytes = .{ 0, 0, 0, 0 };
    try t.expectError(error.NonLoopbackAddress, F.Server.init(t.allocator, t.io, opts));
    opts = options(&handler);
    var server = try F.Server.init(t.allocator, t.io, opts);
    defer server.deinit();
    try t.expect(server.address().getPort() != 0);
    opts.address = server.address();
    try t.expectError(error.AddressInUse, F.Server.init(t.allocator, t.io, opts));
    try server.start();
    const response = try request(server.address(), get);
    defer t.allocator.free(response);
    try t.expect(std.mem.endsWith(u8, response, "/hello"));
    try t.expect(std.mem.find(u8, response, "connection: close") != null);
}

test "P1-HTTP-02 idle peer does not block another request and snapshots own bytes" {
    var handler: Handler = .{};
    var opts = options(&handler);
    opts.observations = .{ .bounded = .{ .max_count = 3, .max_bytes = 100 } };
    var server = try F.Server.init(t.allocator, t.io, opts);
    defer server.deinit();
    try server.start();
    const idle = try server.address().connect(t.io, .{ .mode = .stream });
    defer idle.close(t.io);
    try send(idle, "GET /slow HTTP/1.1\r\n");
    try waitState(&server, .active, 1);
    const response = try request(server.address(), "POST /echo HTTP/1.1\r\nHost: localhost\r\nContent-Length: 4\r\n\r\na\x00bc");
    defer t.allocator.free(response);
    try t.expect(std.mem.endsWith(u8, response, "a\x00bc"));
    const other = try request(server.address(), get);
    defer t.allocator.free(other);
    server.stopAndJoin();
    try t.expectEqual(@as(usize, 0), server.snapshot().active);
    try t.expectEqual(@as(u64, 2), server.snapshot().completed);
    const records = server.observations();
    try t.expectEqual(@as(usize, 2), records.len);
    try t.expectEqualStrings("a\x00bc", records[0].body);
    try t.expectEqualStrings("/echo", records[0].target);
    try t.expect(records[0].connection_id != records[1].connection_id);
}

test "P1-HTTP-03 connection overflow closes excess peer and remains visible" {
    var handler: Handler = .{};
    var opts = options(&handler);
    opts.limits.max_connections = 1;
    var server = try F.Server.init(t.allocator, t.io, opts);
    defer server.deinit();
    try server.start();
    const idle = try server.address().connect(t.io, .{ .mode = .stream });
    defer idle.close(t.io);
    try waitState(&server, .active, 1);
    try rejected(&server, get, error.ConnectionLimitExceeded);
    try t.expectEqual(@as(usize, 1), server.snapshot().active);
}

test "P1-HTTP-03 headers bodies responses and observations reject overflow" {
    for (0..6) |case| {
        var handler: Handler = .{};
        var opts = options(&handler);
        var wire: []const u8 = get;
        const expected: anyerror = switch (case) {
            0 => blk: {
                opts.limits.max_header_bytes = 16;
                break :blk error.HttpHeadersOversize;
            },
            1 => blk: {
                opts.limits.max_request_body_bytes = 1;
                wire = "POST / HTTP/1.1\r\nHost: localhost\r\nContent-Length: 2\r\n\r\nxx";
                break :blk error.RequestBodyTooLarge;
            },
            2 => blk: {
                opts.limits.max_response_bytes = 1;
                break :blk error.ResponseTooLarge;
            },
            3 => blk: {
                opts.observations = .{ .bounded = .{ .max_count = 2, .max_bytes = 1 } };
                break :blk error.ObservationLimitExceeded;
            },
            4 => blk: {
                opts.observations = .{ .bounded = .{ .max_count = 1, .max_bytes = 100 } };
                break :blk error.ObservationLimitExceeded;
            },
            else => blk: {
                opts.limits.max_request_body_bytes = 1;
                wire = "POST / HTTP/1.1\r\nHost: localhost\r\nTransfer-Encoding: chunked\r\n\r\n2\r\nxx\r\n0\r\n\r\n";
                break :blk error.RequestBodyTooLarge;
            },
        };
        var server = try F.Server.init(t.allocator, t.io, opts);
        defer server.deinit();
        try server.start();
        if (case == 4) t.allocator.free(try request(server.address(), get));
        try rejected(&server, wire, expected);
    }
}

test "P1-HTTP-04 idle accept partial head handler and blocked response join on stop" {
    for (0..4) |case| {
        var handler: Handler = .{ .mode = if (case == 2) .hold else if (case == 3) .large else .echo };
        var opts = options(&handler);
        opts.limits.max_response_bytes = 20 * 1024 * 1024;
        var server = try F.Server.init(t.allocator, t.io, opts);
        defer server.deinit();
        try server.start();
        const peer = if (case != 0) try server.address().connect(t.io, .{ .mode = .stream }) else null;
        defer if (peer) |stream| stream.close(t.io);
        if (peer) |stream| {
            try send(stream, if (case == 1) "GET / HTTP/1.1\r\n" else get);
            try waitState(&server, .active, 1);
            if (case >= 2) try handler.entered.waitTimeout(t.io, .{ .duration = .{ .raw = .fromSeconds(2), .clock = .awake } });
            if (case == 3) try t.io.sleep(.fromMilliseconds(30), .awake);
        }
        server.stopAndJoin();
        server.stopAndJoin();
        try t.expectEqual(@as(usize, 0), server.snapshot().active);
        try t.expectEqual(@as(u64, 0), server.snapshot().completed);
        try t.expectEqual(@as(u64, 0), server.snapshot().failures);
    }
}

test "P1-HTTP-04 head total and write deadlines are finite and visible" {
    for (0..3) |case| {
        var handler: Handler = .{ .mode = if (case == 1) .hold else if (case == 2) .large else .echo };
        var opts = options(&handler);
        opts.limits.max_response_bytes = 20 * 1024 * 1024;
        if (case == 0) opts.deadlines.request_head_ms = 30;
        if (case == 1) opts.deadlines.request_total_ms = 30;
        if (case == 2) opts.deadlines.write_ms = 30;
        var server = try F.Server.init(t.allocator, t.io, opts);
        defer server.deinit();
        try server.start();
        const peer = try server.address().connect(t.io, .{ .mode = .stream });
        defer peer.close(t.io);
        try send(peer, if (case == 0) "GET / HTTP/1.1\r\n" else get);
        try waitState(&server, .failed, 1);
        try t.expectEqual(error.DeadlineExceeded, server.snapshot().first_error.?);
        server.stopAndJoin();
        try t.expectEqual(@as(usize, 0), server.snapshot().active);
    }
}

test "P1-HTTP-05 repeated start stop releases resources" {
    var address = options(undefined).address;
    for (0..8) |_| {
        var handler: Handler = .{};
        var opts = options(&handler);
        opts.address = address;
        var server = try F.Server.init(t.allocator, t.io, opts);
        address = server.address();
        try server.start();
        t.allocator.free(try request(server.address(), get));
        server.stopAndJoin();
        try t.expectEqual(@as(u64, 0), server.snapshot().failures);
        try t.expectError(error.ServerStopped, server.start());
        server.deinit();
        server.deinit();
    }
}

test "P1-HTTP-06 handler failure survives teardown and independent fixture recovers" {
    var handler: Handler = .{ .mode = .fail };
    var server = try F.Server.init(t.allocator, t.io, options(&handler));
    defer server.deinit();
    try server.start();
    try rejected(&server, get, error.DeliberateHandlerFailure);
    server.stopAndJoin();
    try t.expectEqual(error.DeliberateHandlerFailure, server.snapshot().first_error.?);
    handler.mode = .echo;
    var recovered = try F.Server.init(t.allocator, t.io, options(&handler));
    defer recovered.deinit();
    try recovered.start();
    t.allocator.free(try request(recovered.address(), get));
    recovered.stopAndJoin();
    try t.expectEqual(@as(u64, 0), recovered.snapshot().failures);
}

test "P1-HTTP-07 abandoned connections are normal partial and malformed heads fail" {
    for ([_][]const u8{ "", "GET / HTTP/1.1\r\nHost:", "not HTTP\r\n\r\n" }, 0..) |wire, index| {
        var handler: Handler = .{};
        var server = try F.Server.init(t.allocator, t.io, options(&handler));
        defer server.deinit();
        try server.start();
        {
            const peer = try server.address().connect(t.io, .{ .mode = .stream });
            defer peer.close(t.io);
            try send(peer, wire);
        }
        try waitState(&server, .finished, 1);
        server.stopAndJoin();
        const state = server.snapshot();
        if (index == 0) {
            try t.expectEqual(@as(u64, 1), state.abandoned);
            try t.expectEqual(@as(u64, 0), state.failures);
        } else try t.expectEqual(if (index == 1) error.HttpRequestTruncated else error.HttpHeadersInvalid, state.first_error.?);
    }
}

fn allocationCase(a: std.mem.Allocator) !void {
    var handler: Handler = .{};
    var opts = options(&handler);
    opts.observations = .{ .bounded = .{ .max_count = 2, .max_bytes = 128 } };
    var server = try F.Server.init(a, t.io, opts);
    defer server.deinit();
    try server.start();
    if (request(server.address(), "POST /echo HTTP/1.1\r\nHost: localhost\r\nContent-Length: 4\r\n\r\nbody")) |response| {
        t.allocator.free(response);
    } else |err| if (err != error.ReadFailed) return err;
    try waitState(&server, .finished, 1);
    server.stopAndJoin();
    if (server.snapshot().first_error) |err| return err;
}
test "P1-HTTP-05 every allocation failure releases request transport and observations" {
    try t.checkAllAllocationFailures(t.allocator, allocationCase, .{});
}
test "P1-HTTP-05 task-start failures close accepted sockets and join listener" {
    for (0..2) |limit| {
        var threaded: Io.Threaded = .init(t.allocator, .{ .concurrent_limit = .limited(limit) });
        defer threaded.deinit();
        const io = threaded.io();
        var handler: Handler = .{};
        var server = try F.Server.init(t.allocator, io, options(&handler));
        defer server.deinit();
        if (limit == 0) {
            try t.expectError(error.ConcurrencyUnavailable, server.start());
        } else {
            try server.start();
            try rejected(&server, get, error.ConcurrencyUnavailable);
            server.stopAndJoin();
            try t.expectEqual(@as(usize, 0), server.snapshot().active);
        }
    }
}

const FaultFactory = struct {
    mode: enum { open, handshake, wait, read, write, flush },
    diagnostic: ?anyerror = null,
    opened: std.atomic.Value(usize) = .init(0),
    destroyed: std.atomic.Value(usize) = .init(0),
    entered: Io.Event = .unset,
    const Adapter = struct {
        factory: *FaultFactory,
        plain: F.transport.Transport,
        bad_reader: Io.Reader = .failing,
        bad_writer: Io.Writer = .failing,
        fn handshake(context: *anyopaque, io: Io, _: Io.Timeout) anyerror!void {
            const self: *@This() = @ptrCast(@alignCast(context));
            self.factory.entered.set(io);
            switch (self.factory.mode) {
                .handshake => return error.SyntheticHandshakeFailed,
                .wait => try io.sleep(.fromSeconds(10), .awake),
                else => {},
            }
        }
        fn deinit(context: *anyopaque, a: std.mem.Allocator) void {
            const self: *@This() = @ptrCast(@alignCast(context));
            _ = self.factory.destroyed.fetchAdd(1, .monotonic);
            self.plain.deinit(self.plain.context, a);
            a.destroy(self);
        }
        fn lastError(context: *anyopaque) ?anyerror {
            const self: *@This() = @ptrCast(@alignCast(context));
            return self.factory.diagnostic;
        }
        fn flush(_: *Io.Writer) Io.Writer.Error!void {
            return error.WriteFailed;
        }
    };
    fn open(context: ?*anyopaque, input: F.transport.Open) anyerror!F.transport.Transport {
        const self: *@This() = @ptrCast(@alignCast(context.?));
        const adapter = try input.allocator.create(Adapter);
        errdefer input.allocator.destroy(adapter);
        if (self.mode == .open) return error.SyntheticOpenFailed;
        adapter.* = .{ .factory = self, .plain = try F.transport.plain(null, input) };
        _ = self.opened.fetchAdd(1, .monotonic);
        if (self.mode == .read) adapter.bad_reader.buffer = input.read_buffer;
        if (self.mode == .flush) adapter.bad_writer = .{ .vtable = &.{ .drain = Io.Writer.failingDrain, .flush = Adapter.flush }, .buffer = input.write_buffer };
        return .{
            .context = adapter,
            .reader = if (self.mode == .read) &adapter.bad_reader else adapter.plain.reader,
            .writer = if (self.mode == .write or self.mode == .flush) &adapter.bad_writer else adapter.plain.writer,
            .handshake = Adapter.handshake,
            .deinit = Adapter.deinit,
            .last_error = Adapter.lastError,
        };
    }
};
test "transport initialization handshake read write flush and timeout release adapter once" {
    for (std.enums.values(@FieldType(FaultFactory, "mode"))) |mode| {
        var fault: FaultFactory = .{ .mode = mode };
        var handler: Handler = .{};
        var opts = options(&handler);
        opts.transport_factory = .{ .context = &fault, .open = FaultFactory.open };
        opts.deadlines.handshake_ms = 30;
        var server = try F.Server.init(t.allocator, t.io, opts);
        defer server.deinit();
        try server.start();
        try rejected(&server, get, switch (mode) {
            .open => error.SyntheticOpenFailed,
            .handshake => error.SyntheticHandshakeFailed,
            .wait => error.DeadlineExceeded,
            .read => error.ReadFailed,
            .write, .flush => error.WriteFailed,
        });
        server.stopAndJoin();
        try t.expectEqual(fault.opened.load(.monotonic), fault.destroyed.load(.monotonic));
        try t.expectEqual(@as(usize, if (mode == .open) 0 else 1), fault.opened.load(.monotonic));
    }
}
test "cancellation interrupts handshake and releases adapter before socket" {
    var fault: FaultFactory = .{ .mode = .wait };
    var handler: Handler = .{};
    var opts = options(&handler);
    opts.transport_factory = .{ .context = &fault, .open = FaultFactory.open };
    var server = try F.Server.init(t.allocator, t.io, opts);
    defer server.deinit();
    try server.start();
    const peer = try server.address().connect(t.io, .{ .mode = .stream });
    defer peer.close(t.io);
    try fault.entered.waitTimeout(t.io, .{ .duration = .{ .raw = .fromSeconds(2), .clock = .awake } });
    server.stopAndJoin();
    try t.expectEqual(@as(usize, 1), fault.destroyed.load(.monotonic));
    try t.expectEqual(@as(usize, 0), server.snapshot().active);
    try t.expectEqual(@as(u64, 0), server.snapshot().failures);
}

test "P1-HTTP-02 overlapping handlers return their own bytes before slow release" {
    var handler: Handler = .{ .mode = .gated };
    var server = try F.Server.init(t.allocator, t.io, options(&handler));
    defer server.deinit();
    try server.start();
    var slow: Probe = .{ .address = server.address(), .wire = "GET /slow HTTP/1.1\r\nHost: localhost\r\n\r\n" };
    defer if (slow.output) |output| t.allocator.free(output);
    var future = try t.io.concurrent(Probe.run, .{&slow});
    defer _ = future.cancel(t.io) catch {};
    try handler.entered.waitTimeout(t.io, .{ .duration = .{ .raw = .fromSeconds(2), .clock = .awake } });
    const fast = try request(server.address(), get);
    defer t.allocator.free(fast);
    try t.expect(std.mem.endsWith(u8, fast, "/hello"));
    handler.release.set(t.io);
    try future.await(t.io);
    try t.expect(std.mem.endsWith(u8, slow.output.?, "/slow"));
    server.stopAndJoin();
    try t.expectEqual(@as(u64, 2), server.snapshot().completed);
    try t.expectEqual(@as(u64, 0), server.snapshot().failures);
}
test "exact body response observation and header bounds accept without clipping" {
    var handler: Handler = .{};
    var opts = options(&handler);
    const wire = "POST / HTTP/1.1\r\nHost: localhost\r\nContent-Length: 4\r\n\r\nbody";
    opts.limits.max_header_bytes = wire.len - 4;
    opts.limits.max_request_body_bytes = 4;
    opts.limits.max_response_bytes = 4;
    opts.observations = .{ .bounded = .{ .max_count = 1, .max_bytes = 5 } };
    var server = try F.Server.init(t.allocator, t.io, opts);
    defer server.deinit();
    try server.start();
    const response = try request(server.address(), wire);
    defer t.allocator.free(response);
    try t.expect(std.mem.endsWith(u8, response, "body"));
    server.stopAndJoin();
    try t.expectEqualStrings("body", server.observations()[0].body);
    try t.expectEqual(@as(u64, 0), server.snapshot().failures);
}
test "response errors cannot be hidden by the handler" {
    var handler: Handler = .{ .mode = .ignored_failure };
    var opts = options(&handler);
    opts.limits.max_response_bytes = 1;
    var server = try F.Server.init(t.allocator, t.io, opts);
    defer server.deinit();
    try server.start();
    try rejected(&server, get, error.ResponseTooLarge);
    server.stopAndJoin();
    try t.expectEqual(@as(u64, 0), server.snapshot().completed);
}

const Planned = struct {
    plan: F.ResponsePlan = .{ .response = .{ .body = "abc\x00def" } },
    raw: ?[]const u8 = null,
    entered: Io.Event = .unset,
    eof: std.atomic.Value(bool) = .init(false),
    calls: usize = 0,
    fn handle(ctx: *anyopaque, input: F.Input) anyerror!void {
        const self: *@This() = @ptrCast(@alignCast(ctx));
        self.entered.set(input.io);
        self.calls += 1;
        // Exercise per-request allocation; no retained observation borrows it.
        @memset(try input.allocator.alloc(u8, 16384), 0xa5);
        if (self.raw) |raw| try input.response.sendRaw(raw) else try input.response.sendPlan(self.plan);
        self.eof.store(input.response.peer_closed, .release);
    }
    fn options(self: *@This()) F.Options {
        var ignored: Handler = .{};
        var result = @import("server.zig").options(&ignored);
        result.handler = .{ .context = self, .handle = handle };
        result.connection_policy = .{ .persistent = .{ .idle_ms = 100, .max_requests = 100 } };
        result.observations = .{ .bounded = .{ .max_count = 128, .max_bytes = 4096 } };
        return result;
    }
};
fn fetch(client: *std.http.Client, address: Io.net.IpAddress) !void {
    const uri_text = try t.allocator.print("http://127.0.0.1:{d}/hello", .{address.getPort()});
    defer t.allocator.free(uri_text);
    var req = try client.request(.GET, try std.Uri.parse(uri_text), .{});
    defer req.deinit();
    try req.sendBodiless();
    var res = try req.receiveHead(&.{});
    var buffer: [128]u8 = undefined;
    const body = try res.reader(&buffer).allocRemaining(t.allocator, .limited(1024));
    defer t.allocator.free(body);
    try t.expectEqualStrings("abc\x00def", body);
}

test "HTTP-03 persistent identities, request storage, idle close and reconnect" {
    var handler: Planned = .{};
    var server = try F.Server.init(t.allocator, t.io, handler.options());
    defer server.deinit();
    try server.start();
    var client: std.http.Client = .{ .allocator = t.allocator, .io = t.io };
    defer client.deinit();
    for (0..50) |_| try fetch(&client, server.address());
    try t.expectEqual(1, server.snapshot().accepted);
    try t.io.sleep(.fromMilliseconds(200), .awake);
    try t.expectEqual(1, server.snapshot().closures[@backingInt(F.CloseReason.idle_deadline)]);
    // A fresh client deliberately reconnects after observable idle expiry.
    client.deinit();
    client = .{ .allocator = t.allocator, .io = t.io };
    try fetch(&client, server.address());
    server.stopAndJoin();
    const rows = server.observations();
    try t.expectEqual(51, rows.len);
    for (rows[0..50], 1..) |row, sequence| {
        try t.expectEqual(1, row.connection_id);
        try t.expectEqual(sequence, row.sequence);
        try t.expectEqualStrings("/hello", row.target);
    }
    try t.expectEqual(2, rows[50].connection_id);
    try t.expectEqual(1, rows[50].sequence);
    try t.expectEqual(0, server.snapshot().active_handlers);
    server.resetObservations();
    try t.expectEqual(0, server.observations().len);
}

test "HTTP-03 bounded request count, explicit close and buffered next request" {
    var handler: Planned = .{};
    var opts = handler.options();
    opts.connection_policy.persistent.max_requests = 2;
    var server = try F.Server.init(t.allocator, t.io, opts);
    defer server.deinit();
    try server.start();
    // Though pipelining is not promised, already-buffered sequential bytes survive.
    const response = try request(server.address(), get ++ get);
    defer t.allocator.free(response);
    try t.expectEqual(2, std.mem.count(u8, response, "abc\x00def"));
    try waitState(&server, .finished, 1);
    try t.expectEqual(1, server.snapshot().closures[@backingInt(F.CloseReason.request_limit)]);
    const close_response = try request(server.address(), "GET / HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n");
    defer t.allocator.free(close_response);
    try waitState(&server, .finished, 2);
    try t.expectEqual(1, server.snapshot().closures[@backingInt(F.CloseReason.client_close)]);
}

test "HTTP-04 chunked response, wire faults and raw upgrade rejection" {
    for (0..5) |mode| {
        var handler: Planned = .{};
        handler.plan.close = true;
        switch (mode) {
            0 => handler.plan.framing = .{ .chunked = .{ .size = 2, .delay_ms = 1 } },
            1 => {
                handler.plan.framing = .{ .chunked = .{ .size = 3 } };
                handler.plan.fault = .omit_final_chunk;
            },
            2 => handler.plan.fault = .{ .length_extra = 5 },
            3 => handler.plan.framing = .close_delimited,
            4 => handler.raw = "HTTP/1.1 101 Invalid\r\nUpgrade: nope\r\n\r\n",
            else => unreachable,
        }
        var server = try F.Server.init(t.allocator, t.io, handler.options());
        defer server.deinit();
        try server.start();
        const wire = try request(server.address(), get);
        defer t.allocator.free(wire);
        switch (mode) {
            0 => try t.expect(std.mem.endsWith(u8, wire, "2\r\nab\r\n2\r\nc\x00\r\n2\r\nde\r\n1\r\nf\r\n0\r\n\r\n")),
            1 => try t.expect(!std.mem.endsWith(u8, wire, "0\r\n\r\n")),
            2 => try t.expect(std.mem.find(u8, wire, "Content-Length: 12\r\n") != null),
            3 => try t.expect(std.mem.find(u8, wire, "Content-Length") == null),
            4 => try t.expectEqualStrings(handler.raw.?, wire),
            else => unreachable,
        }
        try waitState(&server, .finished, 1);
        try t.expectEqual(0, server.snapshot().failures);
        try t.expectEqual(1, server.snapshot().closures[@backingInt(F.CloseReason.intentional)]);
    }
}

test "HTTP-04 withholding observes peer EOF and release barrier cancels cleanly" {
    inline for (.{ .headers, .body }) |phase| {
        var waiting: std.atomic.Value(bool) = .init(false);
        var handler: Planned = .{};
        handler.plan.withhold = phase;
        handler.plan.waiting = &waiting;
        var server = try F.Server.init(t.allocator, t.io, handler.options());
        defer server.deinit();
        try server.start();
        {
            const peer = try server.address().connect(t.io, .{ .mode = .stream });
            defer peer.close(t.io);
            try send(peer, get);
            for (0..1000) |_| {
                if (waiting.load(.acquire)) break;
                try t.io.sleep(.fromMilliseconds(1), .awake);
            }
            try t.expect(waiting.load(.acquire));
            if (phase == .body) {
                var buffer: [1024]u8 = undefined;
                var reader = peer.reader(t.io, &buffer);
                while (try reader.interface.takeByte() != 'a') {}
            }
        }
        try waitState(&server, .finished, 1);
        try t.expect(handler.eof.load(.acquire));
        try t.expectEqual(0, server.snapshot().active_handlers);
    }
    var release: Io.Event = .unset;
    var handler: Planned = .{};
    handler.plan.release = &release;
    var server = try F.Server.init(t.allocator, t.io, handler.options());
    defer server.deinit();
    try server.start();
    const peer = try server.address().connect(t.io, .{ .mode = .stream });
    defer peer.close(t.io);
    try send(peer, get);
    try handler.entered.waitTimeout(t.io, .{ .duration = .{ .raw = .fromSeconds(1), .clock = .awake } });
    server.stopAndJoin();
    try t.expectEqual(0, server.snapshot().active_handlers);
    try t.expectEqual(1, server.snapshot().canceled);
}

test "HTTP-04 delayed chunk stream is joined on shutdown and barrier releases" {
    var release: Io.Event = .unset;
    var handler: Planned = .{};
    handler.plan.release = &release;
    handler.plan.framing = .{ .chunked = .{ .size = 1, .delay_ms = 1000 } };
    var server = try F.Server.init(t.allocator, t.io, handler.options());
    defer server.deinit();
    try server.start();
    const peer = try server.address().connect(t.io, .{ .mode = .stream });
    defer peer.close(t.io);
    try send(peer, get);
    try handler.entered.waitTimeout(t.io, .{ .duration = .{ .raw = .fromSeconds(1), .clock = .awake } });
    try t.expectEqual(1, server.snapshot().active_handlers);
    release.set(t.io);
    var buffer: [1024]u8 = undefined;
    var reader = peer.reader(t.io, &buffer);
    // Head arrival proves the explicit barrier was released before cancellation.
    try t.expectEqual('H', try reader.interface.takeByte());
    server.stopAndJoin();
    try t.expectEqual(0, server.snapshot().active);
    try t.expectEqual(0, server.snapshot().active_handlers);
    try t.expectEqual(1, server.snapshot().canceled);
}

test "transport diagnostics preserve protocol cause through generic reader failure" {
    var fault: FaultFactory = .{ .mode = .read, .diagnostic = error.SyntheticProtocolFailure };
    var handler: Handler = .{};
    var opts = options(&handler);
    opts.transport_factory = .{ .context = &fault, .open = FaultFactory.open };
    var server = try F.Server.init(t.allocator, t.io, opts);
    defer server.deinit();
    try server.start();
    try rejected(&server, get, error.SyntheticProtocolFailure);
}

test "HTTP-04 paced fixed-length bodies preserve binary bytes and framing faults" {
    for (0..3) |mode| {
        var handler: Planned = .{};
        handler.plan.close = true;
        handler.plan.stream = .{ .size = 2, .delay_ms = 1 };
        handler.plan.prefix_before_delay = 1;
        handler.plan.body_delay_ms = 1;
        if (mode == 1) handler.plan.fault = .{ .length_extra = 20 * 1024 * 1024 };
        if (mode == 2) handler.plan.framing = .close_delimited;
        var server = try F.Server.init(t.allocator, t.io, handler.options());
        defer server.deinit();
        try server.start();
        const wire = try request(server.address(), get);
        defer t.allocator.free(wire);
        const head_end = (std.mem.find(u8, wire, "\r\n\r\n") orelse return error.MissingResponseHead) + 4;
        try t.expectEqualStrings("abc\x00def", wire[head_end..]);
        try t.expect(std.mem.find(u8, wire, "Transfer-Encoding") == null);
        if (mode == 0) try t.expect(std.mem.find(u8, wire, "Content-Length: 7\r\n") != null);
        if (mode == 1) try t.expect(std.mem.find(u8, wire, "Content-Length: 20971527\r\n") != null);
        if (mode == 2) try t.expect(std.mem.find(u8, wire, "Content-Length") == null);
        try waitState(&server, .finished, 1);
        try t.expectEqual(0, server.snapshot().active_handlers);
        try t.expectEqual(0, server.snapshot().failures);
    }
}

test "HTTP-04 paced fixed-length transfer stops after the receiving peer closes" {
    const body = try t.allocator.alloc(u8, 1024 * 1024);
    defer t.allocator.free(body);
    @memset(body, 'x');
    var handler: Planned = .{};
    handler.plan.response.body = body;
    handler.plan.stream = .{ .size = 4096, .delay_ms = 20 };
    var opts = handler.options();
    opts.limits.max_response_bytes = body.len;
    opts.deadlines.request_total_ms = 10000;
    var server = try F.Server.init(t.allocator, t.io, opts);
    defer server.deinit();
    try server.start();
    {
        const peer = try server.address().connect(t.io, .{ .mode = .stream });
        defer peer.close(t.io);
        try send(peer, get);
        var buffer: [1024]u8 = undefined;
        var reader = peer.reader(t.io, &buffer);
        // Receiving body bytes proves the response is actively transferring.
        while (try reader.interface.takeByte() != 'x') {}
        try t.expectEqual(1, server.snapshot().active_handlers);
    }
    // This deadline is shorter than the >5-second complete transfer and no
    // server cancellation is requested until after these assertions.
    try waitState(&server, .failed, 1);
    try t.expectEqual(error.WriteFailed, server.snapshot().first_error.?);
    try t.expectEqual(0, server.snapshot().active_handlers);
    try t.expectEqual(0, server.snapshot().active);
    try t.expectEqual(0, server.snapshot().canceled);
    try t.expectEqual(1, server.snapshot().closures[@backingInt(F.CloseReason.failure)]);
}

test "HTTP-04 invalid pacing rejects before publishing headers" {
    for ([_]bool{ false, true }) |conflict| {
        var handler: Planned = .{};
        handler.plan.stream = .{ .size = if (conflict) 1 else 0 };
        if (conflict) handler.plan.framing = .{ .chunked = .{ .size = 1 } };
        var server = try F.Server.init(t.allocator, t.io, handler.options());
        defer server.deinit();
        try server.start();
        try rejected(&server, get, if (conflict) error.ConflictingStreamFraming else error.InvalidStreamSize);
    }
}
