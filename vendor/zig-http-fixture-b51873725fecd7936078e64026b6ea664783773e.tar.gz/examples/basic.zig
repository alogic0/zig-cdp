const std = @import("std");
const F = @import("http_fixture");
fn reply(_: *anyopaque, input: F.Input) anyerror!void {
    try input.response.send(.{ .body = "hello fixture\n", .headers = &.{.{ .name = "Content-Type", .value = "text/plain" }} });
}
pub fn main(init: std.process.Init) !void {
    var context: u8 = 0;
    var server = try F.Server.init(init.gpa, init.io, .{
        .address = try std.Io.net.IpAddress.parse("127.0.0.1", 0),
        .handler = .{ .context = &context, .handle = reply },
        .limits = .{ .max_connections = 4, .max_header_bytes = 4096, .max_request_body_bytes = 1024, .max_response_bytes = 4096 },
        .deadlines = .{ .handshake_ms = 1000, .request_head_ms = 1000, .request_total_ms = 2000, .write_ms = 1000 },
        .connection_policy = .close_after_response,
    });
    defer server.deinit();
    try server.start();
    const stream = try server.address().connect(init.io, .{ .mode = .stream });
    defer stream.close(init.io);
    var wb: [128]u8 = undefined;
    var writer = stream.writer(init.io, &wb);
    try writer.interface.writeAll("GET / HTTP/1.1\r\nHost: localhost\r\n\r\n");
    try writer.interface.flush();
    var rb: [1024]u8 = undefined;
    var reader = stream.reader(init.io, &rb);
    const response = try reader.interface.allocRemaining(init.gpa, .limited(4096));
    defer init.gpa.free(response);
    if (!std.mem.endsWith(u8, response, "hello fixture\n")) return error.UnexpectedResponse;
    server.stopAndJoin();
    const state = server.snapshot();
    if (state.first_error) |err| return err;
    if (state.active != 0 or state.completed != 1) return error.IncompleteCleanup;
    std.debug.print("PASS: loopback response; joined cleanup; native={s}; provider={s}\n", .{ @tagName(@import("builtin").mode), @tagName(F.compiled_mode) });
}
