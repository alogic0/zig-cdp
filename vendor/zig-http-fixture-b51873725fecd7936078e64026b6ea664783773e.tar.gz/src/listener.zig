//! Linux needs SO_REUSEADDR without SO_REUSEPORT for exclusive, restartable
//! listeners. Io.net.listen's reuse_address option enables both on this compiler.
const std = @import("std");
const Io = std.Io;
const linux = std.os.linux;

pub fn open(io: Io, address: Io.net.IpAddress) !Io.net.Server {
    if (@import("builtin").os.tag != .linux) return address.listen(io, .{});
    try io.checkCancel();
    const result = linux.socket(Io.Threaded.posixAddressFamily(&address), linux.SOCK.STREAM | linux.SOCK.CLOEXEC, linux.IPPROTO.TCP);
    switch (std.posix.errno(result)) {
        .SUCCESS => {},
        .MFILE => return error.ProcessFdQuotaExceeded,
        .NFILE => return error.SystemFdQuotaExceeded,
        .AFNOSUPPORT => return error.AddressFamilyUnsupported,
        else => return error.SocketCreationFailed,
    }
    var socket: Io.net.Socket = .{ .handle = @intCast(result), .address = address };
    errdefer socket.close(io);
    const enabled: c_int = 1;
    try std.posix.setsockopt(socket.handle, linux.SOL.SOCKET, linux.SO.REUSEADDR, std.mem.asBytes(&enabled));
    var storage: Io.Threaded.PosixAddress = undefined;
    var length = Io.Threaded.addressToPosix(&address, &storage);
    while (true) {
        try io.checkCancel();
        switch (std.posix.errno(linux.bind(socket.handle, &storage.any, length))) {
            .SUCCESS => break,
            .INTR => continue,
            .ADDRINUSE => return error.AddressInUse,
            .ADDRNOTAVAIL => return error.AddressUnavailable,
            .ACCES => return error.AccessDenied,
            else => return error.SocketBindFailed,
        }
    }
    while (true) {
        try io.checkCancel();
        switch (std.posix.errno(linux.listen(socket.handle, Io.net.default_kernel_backlog))) {
            .SUCCESS => break,
            .INTR => continue,
            .ADDRINUSE => return error.AddressInUse,
            else => return error.SocketListenFailed,
        }
    }
    if (std.posix.errno(linux.getsockname(socket.handle, &storage.any, &length)) != .SUCCESS) return error.SocketAddressFailed;
    socket.address = Io.Threaded.addressFromPosix(&storage);
    return .{ .socket = socket, .options = {} };
}
