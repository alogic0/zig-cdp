//! Adapters borrow the socket and buffers; only the server closes the socket.
const std = @import("std");
const Io = std.Io;
const A = std.mem.Allocator;

pub const Open = struct {
    allocator: A,
    io: Io,
    stream: Io.net.Stream,
    read_buffer: []u8,
    write_buffer: []u8,
    deadline: Io.Timeout,
};
pub const Transport = struct {
    context: *anyopaque,
    reader: *Io.Reader,
    writer: *Io.Writer,
    handshake: *const fn (*anyopaque, Io, Io.Timeout) anyerror!void,
    deinit: *const fn (*anyopaque, A) void,
    /// Recover protocol/cancellation details hidden by Reader/Writer error sets.
    last_error: ?*const fn (*anyopaque) ?anyerror = null,
};
pub const Factory = struct {
    context: ?*anyopaque = null,
    open: *const fn (?*anyopaque, Open) anyerror!Transport = plain,
};

const Plain = struct {
    reader: Io.net.Stream.Reader,
    writer: Io.net.Stream.Writer,
    fn handshake(_: *anyopaque, io: Io, _: Io.Timeout) anyerror!void {
        try io.checkCancel();
    }
    fn deinit(context: *anyopaque, a: A) void {
        const self: *@This() = @ptrCast(@alignCast(context));
        a.destroy(self);
    }
};
pub fn plain(_: ?*anyopaque, input: Open) anyerror!Transport {
    const state = try input.allocator.create(Plain);
    state.* = .{ .reader = input.stream.reader(input.io, input.read_buffer), .writer = input.stream.writer(input.io, input.write_buffer) };
    return .{ .context = state, .reader = &state.reader.interface, .writer = &state.writer.interface, .handshake = Plain.handshake, .deinit = Plain.deinit };
}
