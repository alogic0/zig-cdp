//! Valid responses and deliberately selected wire faults. All bytes are borrowed.
const std = @import("std");
const Io = std.Io;
const D = @import("deadline.zig");
pub const Response = struct {
    body: []const u8,
    status: std.http.Status = .ok,
    headers: []const std.http.Header = &.{},
    reason: ?[]const u8 = null,
};
pub const Plan = struct {
    response: Response,
    framing: union(enum) {
        content_length,
        chunked: struct { size: usize, delay_ms: u32 = 0 },
        close_delimited,
    } = .content_length,
    /// These modes intentionally violate HTTP framing and always close.
    fault: union(enum) { none, length_extra: usize, omit_final_chunk } = .none,
    header_delay_ms: u32 = 0,
    body_delay_ms: u32 = 0,
    prefix_before_delay: usize = 0,
    /// Pace fixed-length or close-delimited bodies without chunked wire framing.
    /// The body remains borrowed and bounded; delays stay inside the request budget.
    stream: ?struct { size: usize, delay_ms: u32 = 0 } = null,
    release: ?*Io.Event = null,
    release_ms: u32 = 30000,
    withhold: enum { none, headers, body } = .none,
    peer_close_ms: u32 = 15000,
    /// Set immediately before waiting for peer EOF; borrowed until send returns.
    waiting: ?*std.atomic.Value(bool) = null,
    disconnect: bool = false,
    close: bool = false,
};
pub const ResponseWriter = struct {
    io: Io,
    native: *std.http.Server.Request,
    limit: usize,
    write_ms: u32,
    keep_alive: bool = false,
    close: bool = false,
    peer_closed: bool = false,
    sent: bool = false,
    attempted: bool = false,
    failure: ?anyerror = null,

    pub fn send(self: *ResponseWriter, response: Response) !void {
        return self.sendPlan(.{ .response = response });
    }
    pub fn sendPlan(self: *ResponseWriter, plan: Plan) !void {
        self.planInner(plan) catch |err| {
            self.failure = self.failure orelse err;
            return err;
        };
    }
    fn validate(self: *ResponseWriter, response: Response) !void {
        if (self.attempted) return error.ResponseAlreadySent;
        if (@backingInt(response.status) < 200) return error.UnsupportedResponseStatus;
        var size = response.body.len;
        if (response.reason) |reason| {
            for (reason) |c| if (c == '\r' or c == '\n' or c == 0) return error.InvalidResponseHeader;
            size = std.math.add(usize, size, reason.len) catch return error.ResponseTooLarge;
        }
        for (response.headers) |header| {
            if (header.name.len == 0) return error.InvalidResponseHeader;
            for (header.name) |c| if (!std.ascii.isAlphanumeric(c) and std.mem.findScalar(u8, "!#$%&'*+-.^_`|~", c) == null) return error.InvalidResponseHeader;
            for (header.value) |c| if (c == '\r' or c == '\n' or c == 0) return error.InvalidResponseHeader;
            for ([_][]const u8{ "content-length", "transfer-encoding", "connection" }) |reserved|
                if (std.ascii.eqlIgnoreCase(header.name, reserved)) return error.ReservedResponseHeader;
            size = std.math.add(usize, size, header.name.len) catch return error.ResponseTooLarge;
            size = std.math.add(usize, size, header.value.len) catch return error.ResponseTooLarge;
        }
        if (size > self.limit) return error.ResponseTooLarge;
    }
    fn planInner(self: *ResponseWriter, plan: Plan) anyerror!void {
        try self.validate(plan.response);
        if (plan.framing == .chunked and plan.framing.chunked.size == 0) return error.InvalidChunkSize;
        if (plan.stream) |stream| {
            if (stream.size == 0) return error.InvalidStreamSize;
            if (plan.framing == .chunked) return error.ConflictingStreamFraming;
        }
        if (plan.fault == .omit_final_chunk and plan.framing != .chunked) return error.InvalidFramingFault;
        if (plan.fault == .length_extra and plan.framing != .content_length) return error.InvalidFramingFault;
        const length = std.math.add(usize, plan.response.body.len, if (plan.fault == .length_extra) plan.fault.length_extra else 0) catch return error.ResponseTooLarge;
        if (plan.withhold != .none and plan.peer_close_ms == 0) return error.InvalidPeerDeadline;
        self.attempted = true;
        self.close = plan.close or plan.disconnect or plan.withhold != .none or plan.fault != .none or plan.framing == .close_delimited;
        if (plan.release) |release| {
            if (plan.release_ms == 0) return error.InvalidReleaseDeadline;
            release.waitTimeout(self.io, D.timeout(plan.release_ms)) catch |err| return if (err == error.Timeout) error.ReleaseDeadlineExceeded else err;
        }
        if (plan.withhold == .headers) {
            try self.waitPeer(plan);
        } else if (!plan.disconnect) {
            if (plan.header_delay_ms != 0) try self.io.sleep(.fromMilliseconds(plan.header_delay_ms), .awake);
            try D.within(self.io, D.timeout(self.write_ms), writeHead, .{ self, plan, length });
            if (plan.withhold == .body) {
                try self.write(plan.response.body[0..@min(1, plan.response.body.len)]);
                try self.waitPeer(plan);
            } else if (self.native.head.method != .HEAD) {
                const body = plan.response.body;
                const prefix = if (plan.framing == .chunked) 0 else @min(body.len, plan.prefix_before_delay);
                if (prefix != 0) try self.write(body[0..prefix]);
                if (plan.body_delay_ms != 0) try self.io.sleep(.fromMilliseconds(plan.body_delay_ms), .awake);
                if (plan.framing == .chunked) {
                    const chunk = plan.framing.chunked;
                    var offset: usize = 0;
                    while (offset < body.len) {
                        if (chunk.delay_ms != 0) try self.io.sleep(.fromMilliseconds(chunk.delay_ms), .awake);
                        const end = offset + @min(chunk.size, body.len - offset);
                        try D.within(self.io, D.timeout(self.write_ms), writeChunk, .{ self, body[offset..end] });
                        offset = end;
                    }
                    if (plan.fault != .omit_final_chunk) try self.write("0\r\n\r\n");
                } else if (plan.stream) |stream| {
                    var offset = prefix;
                    while (offset < body.len) {
                        const end = offset + @min(stream.size, body.len - offset);
                        try self.write(body[offset..end]);
                        offset = end;
                        if (offset < body.len and stream.delay_ms != 0) try self.io.sleep(.fromMilliseconds(stream.delay_ms), .awake);
                    }
                } else try self.write(body[prefix..]);
            }
        }
        self.sent = true;
    }
    fn writeHead(self: *ResponseWriter, plan: Plan, length: usize) anyerror!void {
        const out = self.native.server.out;
        const response = plan.response;
        try out.print("HTTP/1.1 {d} {s}\r\n", .{ @backingInt(response.status), response.reason orelse response.status.phrase() orelse "" });
        if (!self.keep_alive or self.close) try out.writeAll("connection: close\r\n");
        switch (plan.framing) {
            .content_length => try out.print("Content-Length: {d}\r\n", .{length}),
            .chunked => try out.writeAll("Transfer-Encoding: chunked\r\n"),
            .close_delimited => {},
        }
        for (response.headers) |header| try out.print("{s}: {s}\r\n", .{ header.name, header.value });
        try out.writeAll("\r\n");
        try out.flush();
    }
    fn writeChunk(self: *ResponseWriter, bytes: []const u8) anyerror!void {
        const out = self.native.server.out;
        try out.print("{x}\r\n", .{bytes.len});
        try out.writeAll(bytes);
        try out.writeAll("\r\n");
        try out.flush();
    }
    fn write(self: *ResponseWriter, bytes: []const u8) !void {
        try D.within(self.io, D.timeout(self.write_ms), writeInner, .{ self, bytes });
    }
    fn writeInner(self: *ResponseWriter, bytes: []const u8) anyerror!void {
        try self.native.server.out.writeAll(bytes);
        try self.native.server.out.flush();
    }
    fn waitPeer(self: *ResponseWriter, plan: Plan) !void {
        if (plan.waiting) |waiting| waiting.store(true, .release);
        try D.within(self.io, D.timeout(plan.peer_close_ms), peerEof, .{self});
        self.peer_closed = true;
    }
    fn peerEof(self: *ResponseWriter) anyerror!void {
        if (self.native.server.reader.in.takeByte()) |_| return error.UnexpectedPeerData else |err| if (err != error.EndOfStream) return err;
    }
    /// Deliberately malformed HTTP, e.g. a rejected upgrade. Always closes.
    pub fn sendRaw(self: *ResponseWriter, wire: []const u8) !void {
        self.rawInner(wire) catch |err| {
            self.failure = self.failure orelse err;
            return err;
        };
    }
    fn rawInner(self: *ResponseWriter, wire: []const u8) !void {
        if (self.attempted) return error.ResponseAlreadySent;
        if (wire.len > self.limit) return error.ResponseTooLarge;
        self.attempted = true;
        self.close = true;
        try self.write(wire);
        self.sent = true;
    }
};
