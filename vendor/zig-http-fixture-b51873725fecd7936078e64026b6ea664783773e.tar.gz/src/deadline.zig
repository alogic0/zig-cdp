const std = @import("std");
const Io = std.Io;
pub fn timeout(ms: u32) Io.Timeout {
    return .{ .duration = .{ .raw = .fromMilliseconds(ms), .clock = .awake } };
}
pub fn within(io: Io, budget: Io.Timeout, comptime function: anytype, args: anytype) anyerror!void {
    const Result = union(enum) { operation: anyerror!void, timer: Io.Cancelable!void };
    var results: [2]Result = undefined;
    var select: Io.Select(Result) = .init(io, &results);
    defer select.cancelDiscard();
    try select.concurrent(.operation, function, args);
    try select.concurrent(.timer, Io.Timeout.sleep, .{ budget, io });
    switch (try select.await()) {
        .operation => |result| try result,
        .timer => |result| {
            try result;
            return error.DeadlineExceeded;
        },
    }
}
