//! Bounded concurrent loopback HTTP fixtures. Callbacks own application policy.
const std = @import("std");
const Io = std.Io;
const A = std.mem.Allocator;
pub const transport = @import("transport.zig");
pub const compiled_mode = @import("builtin").mode;

pub const Limits = struct {
    max_connections: usize,
    max_header_bytes: usize,
    max_request_body_bytes: usize,
    max_response_bytes: usize,
};
pub const Deadlines = struct {
    handshake_ms: u32,
    request_head_ms: u32,
    request_total_ms: u32,
    write_ms: u32,
};
pub const Observations = union(enum) {
    none,
    bounded: struct { max_count: usize, max_bytes: usize },
};
pub const Options = struct {
    address: Io.net.IpAddress,
    handler: Handler,
    limits: Limits,
    deadlines: Deadlines,
    connection_policy: ConnectionPolicy,
    on_close: ?ClosureObserver = null,
    transport_factory: transport.Factory = .{},
    observations: Observations = .none,
};
pub const Request = struct {
    method: std.http.Method,
    target: []const u8,
    head_bytes: []const u8,
    body: []const u8,
    connection_id: u64,
    sequence: u64 = 1,
    pub fn headers(self: Request) std.http.HeaderIterator {
        return .init(self.head_bytes);
    }
};
pub const Input = struct {
    io: Io,
    allocator: A,
    request: *const Request,
    response: *ResponseWriter,
};
pub const Handler = struct {
    context: *anyopaque,
    handle: *const fn (*anyopaque, Input) anyerror!void,
};
pub const Response = @import("response.zig").Response;
pub const ResponseWriter = @import("response.zig").ResponseWriter;
pub const ResponsePlan = @import("response.zig").Plan;
pub const ConnectionPolicy = union(enum) {
    close_after_response,
    persistent: struct { idle_ms: u32, max_requests: u64 },
};
pub const CloseReason = enum { response, client_close, peer_eof, idle_deadline, request_limit, intentional, canceled, failure };
pub const Closure = struct { connection_id: u64, requests: u64, reason: CloseReason, failure: ?anyerror = null };
pub const ClosureObserver = struct { context: *anyopaque, handle: *const fn (*anyopaque, Closure) void };
pub const Snapshot = struct {
    accepted: u64 = 0,
    active: usize = 0,
    completed: u64 = 0,
    abandoned: u64 = 0,
    canceled: u64 = 0,
    failures: u64 = 0,
    first_error: ?anyerror = null,
    requests: u64 = 0,
    active_handlers: usize = 0,
    closures: [8]u64 = @splat(0),
};
pub const Observation = struct {
    connection_id: u64,
    sequence: u64,
    method: std.http.Method,
    target: []const u8,
    body: []const u8,
};

pub const Server = struct {
    allocator: A,
    io: Io,
    options: Options,
    listener: ?Io.net.Server,
    bound_address: Io.net.IpAddress,
    group: Io.Group = .init,
    lock: Io.Mutex = .init,
    state: Snapshot = .{},
    records: std.ArrayList(Observation) = .empty,
    record_bytes: usize = 0,
    started: bool = false,
    stopped: bool = false,

    pub fn init(a: A, io: Io, options: Options) !Server {
        const loopback = switch (options.address) {
            .ip4 => |ip| ip.bytes[0] == 127,
            .ip6 => |ip| std.mem.eql(u8, ip.bytes[0..15], &@as([15]u8, @splat(0))) and ip.bytes[15] == 1,
        };
        if (!loopback) return error.NonLoopbackAddress;
        const l = options.limits;
        const d = options.deadlines;
        if (l.max_connections == 0 or l.max_header_bytes < 16 or l.max_response_bytes == 0 or
            d.handshake_ms == 0 or d.request_head_ms == 0 or d.request_total_ms == 0 or d.write_ms == 0) return error.InvalidOptions;
        if (options.observations == .bounded and (options.observations.bounded.max_count == 0 or options.observations.bounded.max_bytes == 0)) return error.InvalidOptions;
        if (options.connection_policy == .persistent and (options.connection_policy.persistent.idle_ms == 0 or options.connection_policy.persistent.max_requests == 0)) return error.InvalidOptions;
        const listener = try @import("listener.zig").open(io, options.address);
        return .{ .allocator = a, .io = io, .options = options, .listener = listener, .bound_address = listener.socket.address };
    }
    pub fn address(self: *const Server) Io.net.IpAddress {
        return self.bound_address;
    }
    /// Keep this object, handler context and factory context stable until join.
    pub fn start(self: *Server) !void {
        if (self.stopped) return error.ServerStopped;
        if (self.started) return error.AlreadyStarted;
        try self.group.concurrent(self.io, serve, .{self});
        self.started = true;
    }
    /// Owner-thread operation; idempotent. Cancellation propagates into callbacks.
    pub fn stopAndJoin(self: *Server) void {
        if (self.stopped) return;
        self.group.cancel(self.io);
        if (self.listener) |*listener| listener.deinit(self.io);
        self.listener = null;
        self.stopped = true;
    }
    pub fn deinit(self: *Server) void {
        self.stopAndJoin();
        self.resetObservations();
    }
    /// Owner-thread only, after join. Releases all retained request bytes.
    pub fn resetObservations(self: *Server) void {
        std.debug.assert(self.stopped);
        for (self.records.items) |record| {
            self.allocator.free(record.target);
            self.allocator.free(record.body);
        }
        self.records.deinit(self.allocator);
        self.records = .empty;
        self.record_bytes = 0;
    }
    pub fn snapshot(self: *Server) Snapshot {
        self.lock.lockUncancelable(self.io);
        defer self.lock.unlock(self.io);
        return self.state;
    }
    /// Borrowed until deinit; inspect only after stopAndJoin.
    pub fn observations(self: *const Server) []const Observation {
        std.debug.assert(self.stopped);
        return self.records.items;
    }
    fn failure(self: *Server, err: anyerror) void {
        self.lock.lockUncancelable(self.io);
        defer self.lock.unlock(self.io);
        self.state.failures += 1;
        if (self.state.first_error == null) self.state.first_error = err;
    }
    fn serve(self: *Server) void {
        self.acceptLoop() catch |err| if (err != error.Canceled) self.failure(err);
    }
    fn acceptLoop(self: *Server) !void {
        var connections: Io.Group = .init;
        defer connections.cancel(self.io);
        while (true) {
            const stream = try self.listener.?.accept(self.io);
            const id = self.admit() catch |err| {
                stream.close(self.io);
                self.failure(err);
                if (err == error.ConnectionIdExhausted) return;
                continue;
            };
            connections.concurrent(self.io, connection, .{ self, stream, id }) catch |err| {
                stream.close(self.io);
                self.release();
                return err;
            };
        }
    }
    fn admit(self: *Server) !u64 {
        self.lock.lockUncancelable(self.io);
        defer self.lock.unlock(self.io);
        if (self.state.active >= self.options.limits.max_connections) return error.ConnectionLimitExceeded;
        if (self.state.accepted == std.math.maxInt(u64)) return error.ConnectionIdExhausted;
        self.state.accepted += 1;
        self.state.active += 1;
        return self.state.accepted;
    }
    fn release(self: *Server) void {
        self.lock.lockUncancelable(self.io);
        defer self.lock.unlock(self.io);
        self.state.active -= 1;
    }
    fn connection(self: *Server, stream: Io.net.Stream, id: u64) void {
        defer self.release();
        var closure: Closure = .{ .connection_id = id, .requests = 0, .reason = .response };
        // exchange tears down the adapter before closing the borrowed socket.
        self.exchange(stream, &closure) catch |err| {
            closure.failure = err;
            closure.reason = switch (err) {
                error.HttpConnectionClosing, error.EndOfStream => .peer_eof,
                error.Canceled => .canceled,
                error.IdleDeadlineExceeded => .idle_deadline,
                else => .failure,
            };
        };
        stream.close(self.io);
        self.lock.lockUncancelable(self.io);
        self.state.closures[@backingInt(closure.reason)] += 1;
        switch (closure.reason) {
            .peer_eof => if (closure.requests == 0) {
                self.state.abandoned += 1;
            } else {
                self.state.completed += 1;
            },
            .canceled => self.state.canceled += 1,
            .failure => {
                self.state.failures += 1;
                if (self.state.first_error == null) self.state.first_error = closure.failure;
            },
            else => self.state.completed += 1,
        }
        self.lock.unlock(self.io);
        if (self.options.on_close) |observer| observer.handle(observer.context, closure);
    }
    fn exchange(self: *Server, stream: Io.net.Stream, closure: *Closure) !void {
        const rb = try self.allocator.alloc(u8, self.options.limits.max_header_bytes);
        defer self.allocator.free(rb);
        var wb: [4096]u8 = undefined;
        var connection_state: Connection = .{ .owner = self, .stream = stream, .id = closure.connection_id, .read_buffer = rb, .write_buffer = &wb };
        defer if (connection_state.adapter) |adapter| adapter.deinit(adapter.context, self.allocator);
        const deadline = timeout(self.options.deadlines.handshake_ms).toDeadline(self.io);
        try within(self.io, deadline, Connection.open, .{ &connection_state, deadline });
        var http = std.http.Server.init(connection_state.adapter.?.reader, connection_state.adapter.?.writer);
        while (true) {
            if (closure.requests > 0) {
                const policy = self.options.connection_policy.persistent;
                within(self.io, timeout(policy.idle_ms), Connection.waitByte, .{connection_state.adapter.?.reader}) catch |err| return if (err == error.DeadlineExceeded) error.IdleDeadlineExceeded else connection_state.cause(err);
            }
            connection_state.sequence = closure.requests + 1;
            within(self.io, timeout(self.options.deadlines.request_total_ms), Connection.request, .{ &connection_state, &http }) catch |err| return connection_state.cause(err);
            closure.requests += 1;
            if (connection_state.close_reason) |reason| {
                closure.reason = reason;
                return;
            }
        }
    }
    fn observe(self: *Server, request: Request) !void {
        const limits = switch (self.options.observations) {
            .none => return,
            .bounded => |limits| limits,
        };
        self.lock.lockUncancelable(self.io);
        defer self.lock.unlock(self.io);
        const bytes = std.math.add(usize, request.target.len, request.body.len) catch return error.ObservationLimitExceeded;
        if (self.records.items.len >= limits.max_count or bytes > limits.max_bytes - self.record_bytes) return error.ObservationLimitExceeded;
        const target = try self.allocator.dupe(u8, request.target);
        errdefer self.allocator.free(target);
        const body = try self.allocator.dupe(u8, request.body);
        errdefer self.allocator.free(body);
        try self.records.append(self.allocator, .{ .connection_id = request.connection_id, .sequence = request.sequence, .method = request.method, .target = target, .body = body });
        self.record_bytes += bytes;
    }
};

const Connection = struct {
    owner: *Server,
    stream: Io.net.Stream,
    id: u64,
    read_buffer: []u8,
    write_buffer: []u8,
    adapter: ?transport.Transport = null,
    sequence: u64 = 1,
    close_reason: ?CloseReason = null,
    fn cause(self: *@This(), err: anyerror) anyerror {
        if (err == error.ReadFailed or err == error.WriteFailed or err == error.HttpHeadersUnreadable) {
            const adapter = self.adapter.?;
            if (adapter.last_error) |last_error| return last_error(adapter.context) orelse err;
        }
        return err;
    }
    fn open(self: *@This(), deadline: Io.Timeout) anyerror!void {
        const owner = self.owner;
        self.adapter = try owner.options.transport_factory.open(owner.options.transport_factory.context, .{
            .allocator = owner.allocator,
            .io = owner.io,
            .stream = self.stream,
            .read_buffer = self.read_buffer,
            .write_buffer = self.write_buffer,
            .deadline = deadline,
        });
        const adapter = self.adapter.?;
        try adapter.handshake(adapter.context, owner.io, deadline);
    }
    fn receive(server: *std.http.Server, destination: *?std.http.Server.Request) anyerror!void {
        destination.* = try server.receiveHead();
    }
    fn waitByte(reader: *Io.Reader) anyerror!void {
        _ = try reader.peekByte();
    }
    fn request(self: *@This(), http: *std.http.Server) anyerror!void {
        const owner = self.owner;
        var native: ?std.http.Server.Request = null;
        try within(owner.io, timeout(owner.options.deadlines.request_head_ms), receive, .{ http, &native });
        const req = &native.?;
        var arena = std.heap.ArenaAllocator.init(owner.allocator);
        defer arena.deinit();
        const a = arena.allocator();
        const method = req.head.method;
        const target = try a.dupe(u8, req.head.target);
        const head_bytes = try a.dupe(u8, req.head_buffer);
        if (req.head.content_length) |length| if (length > owner.options.limits.max_request_body_bytes) return error.RequestBodyTooLarge;
        const body_reader = try req.readerExpectContinue(&.{});
        const body = body_reader.allocRemaining(a, .limited(owner.options.limits.max_request_body_bytes)) catch |err| switch (err) {
            error.StreamTooLong => return error.RequestBodyTooLarge,
            else => return err,
        };
        const input: Request = .{ .method = method, .target = target, .head_bytes = head_bytes, .body = body, .connection_id = self.id, .sequence = self.sequence };
        try owner.observe(input);
        self.close_reason = switch (owner.options.connection_policy) {
            .close_after_response => .response,
            .persistent => |policy| if (self.sequence >= policy.max_requests) .request_limit else if (!req.head.keep_alive) .client_close else null,
        };
        owner.lock.lockUncancelable(owner.io);
        owner.state.requests += 1;
        owner.state.active_handlers += 1;
        owner.lock.unlock(owner.io);
        defer {
            owner.lock.lockUncancelable(owner.io);
            owner.state.active_handlers -= 1;
            owner.lock.unlock(owner.io);
        }
        var response: ResponseWriter = .{ .io = owner.io, .native = req, .limit = owner.options.limits.max_response_bytes, .write_ms = owner.options.deadlines.write_ms, .keep_alive = self.close_reason == null };
        try owner.options.handler.handle(owner.options.handler.context, .{ .io = owner.io, .allocator = a, .request = &input, .response = &response });
        if (response.failure) |err| return err;
        if (!response.sent) return error.ResponseMissing;
        if (response.close) self.close_reason = .intentional;
    }
};
const timeout = @import("deadline.zig").timeout;
const within = @import("deadline.zig").within;
