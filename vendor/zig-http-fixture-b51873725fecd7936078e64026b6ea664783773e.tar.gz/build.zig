const std = @import("std");
pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});
    const module = b.addModule("http_fixture", .{ .root_source_file = b.path("src/root.zig"), .target = target, .optimize = optimize });
    const tests = b.addTest(.{ .root_module = b.createModule(.{ .root_source_file = b.path("tests/server.zig"), .target = target, .optimize = optimize, .imports = &.{.{ .name = "http_fixture", .module = module }} }) });
    const run_tests = b.addRunArtifact(tests);
    run_tests.has_side_effects = true;
    b.step("test", "Run real-socket ownership and failure regressions").dependOn(&run_tests.step);
    const example = b.addExecutable(.{ .name = "fixture-example", .root_module = b.createModule(.{ .root_source_file = b.path("examples/basic.zig"), .target = target, .optimize = optimize, .imports = &.{.{ .name = "http_fixture", .module = module }} }) });
    b.installArtifact(example);
    const run_example = b.addRunArtifact(example);
    run_example.has_side_effects = true;
    b.step("example", "Run a finite loopback request and clean up").dependOn(&run_example.step);
}
