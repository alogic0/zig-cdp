# Changelog

## 0.2.1

- Pace fixed-length and close-delimited bodies independently of HTTP chunk framing.
- Preserve declared-length fault controls during paced transfer; verify that a
  client disconnect ends the active writer and surfaces a closure failure.

## 0.1.0

Initial concurrent loopback fixture core: bounded requests and complete responses,
request-scoped storage, optional owned observations, finite deadlines and joined
cleanup. Includes a protocol adapter boundary, real-socket ownership/failure tests,
a finite example and an independent archive-package consumer.

Only close-after-response HTTP is delivered. Provider verification and each
application's adoption remain separate acceptance records.

## 0.2.0

- Persistent sequential HTTP with request-scoped storage, connection/sequence IDs,
  finite idle/request-count policy, closure callbacks and counters.
- Response plans for chunked streams, delays, release barriers, peer-EOF withholding,
  disconnects, close delimiting and explicit malformed framing/raw wire responses.
- Joined cancellation during streams and barriers; resettable owned observations.
- Provider readiness is separate from consumer TLS/application acceptance.
