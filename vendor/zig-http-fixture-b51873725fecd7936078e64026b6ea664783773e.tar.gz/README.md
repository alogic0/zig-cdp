# zig-http-fixture

Version 0.2.1 adds paced fixed-length/close-delimited transfers through
`ResponsePlan.stream`. It preserves declared-length fault controls and surfaces
client-disconnect write failures through closure observations. See
[the transfer contract](DESIGN.md#paced-fixed-length-transfer-021).

A small Zig library for bounded concurrent loopback HTTP test servers.
Requires the compiler pinned in `.zigversion` (0.17.0). No external dependencies.
The initial supported and verified platform is Linux.

```sh
zig build test example -Doptimize=Debug
zig build test example -Doptimize=ReleaseSafe
```

The [finite example](examples/basic.zig) starts a fixture, makes a real request,
checks the response and joins all server work. Import the `http_fixture` module
from a dependency configured with the consumer's target and optimization mode.
`compiled_mode` exposes the provider's actual mode for acceptance checks.

The caller supplies a loopback address (port zero is supported), handler context,
limits, deadlines and an explicit `close_after_response` or bounded `persistent` policy. Call `start`
only after the server has its final address in memory. Keep the server and borrowed
contexts stable until `stopAndJoin`; call `deinit` to release observation storage.
Use `snapshot().first_error` to reject failed fixtures, including asynchronous
handler and admission failures. Shutdown does not erase earlier failures.

Handlers receive borrowed request bytes, a request-scoped allocator and a response
writer. Application routes, assets and assertions stay in the caller. Send one
complete response with `input.response.send(.{ .body = bytes })`. The bytes need
only outlive the send. Optional bounded observations copy targets and bodies;
inspect them after join, before deinit. See [ownership and limits](DESIGN.md).

Version 0.2 supports sequential persistent requests, bounded idle/request-count
policies, stable connection IDs and sequence numbers. Response plans provide
chunk streaming, delays, release barriers, withholding with peer EOF observation,
disconnects and explicitly selected framing faults. `sendRaw` sends malformed
protocol bytes and always closes. Closure callbacks and counters distinguish
normal policy closure, peer EOF, cancellation, idle expiry and failures.

The transport factory keeps protocol state across requests and has a bounded
handshake. Adapters borrow the socket; the core joins I/O, destroys adapter state,
then closes the socket. Plain and synthetic transport tests run here; actual TLS
implementation and integration checks belong to consumers.

## Isolated package check

From a committed checkout, create an archive and a temporary directory, then
copy only `tests/package/*` and the archive into that directory. In that directory:

```sh
zig fetch --save=http_fixture ./provider.tar.gz
zig build test -Doptimize=Debug
zig build test -Doptimize=ReleaseSafe
```

The generated manifest records the immutable content hash. CI performs this check
with a fresh global cache, outside the provider checkout. Consumer repositories
can retain the verified archive and pin its content hash without a sibling path.
