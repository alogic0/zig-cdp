# Changelog

## 0.1.0

- Bounded command reports, optional stdin and asynchronous joined capture owners.
- Bounded readiness lines/files retaining process/result ownership across races.
- Private workspaces with explicit cleanup and failure retention.
- Owned diagnostic excerpts preserving primary and secondary cleanup errors.
- Independent file, JSON, PNG-header and Linux resource helpers.
- Compiler 0.17.0; Linux provider support. Consumer adoption tracked separately.
